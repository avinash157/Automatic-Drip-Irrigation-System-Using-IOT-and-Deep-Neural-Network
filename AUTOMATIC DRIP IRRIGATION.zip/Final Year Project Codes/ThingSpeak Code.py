import time
import requests
import numpy as np
from joblib import load

# Function to retrieve data from ThingSpeak
def get_thingspeak_data(channel_id, read_api_key):
    try:
        url = f'https://api.thingspeak.com/channels/{channel_id}/feeds.json'
        params = {'api_key': read_api_key, 'results': 1}  # Get the latest entry
        response = requests.get(url, params=params)
        
        print("URL:", response.url)  # Print the URL used for the request
        
        if response.status_code == 200:
            data = response.json()
            print("Received Data:", data)  # Print the received data
            return data
        else:
            print("Error accessing ThingSpeak API. Status code:", response.status_code)
            print("Response content:", response.content)
            return None
    except Exception as e:
        print("An error occurred during data retrieval:", str(e))
        return None

# Function to load model from joblib file
def load_model(file_path):
    try:
        model = load(file_path)
        return model
    except Exception as e:
        print("Error loading model:", str(e))
        return None

# Function to classify data using the loaded model
def classify_data(model, N,P,K,Conductivity,PH):
    if N is not None and P is not None:
        input_features = np.array([[N,P,K,Conductivity,PH]])
        prediction = model.predict(input_features)
        return int(prediction[0])
    else:
        print("Warning: Conductivityerature or air quality values are None. Skipping classification.")
        return None

# Function to send classification result to ThingSpeak
# Function to send classification result to ThingSpeak field3
def send_classification_result(channel_id, write_api_key, classification_result):
    try:
        url = f'https://api.thingspeak.com/update.json'
        params = {'api_key': write_api_key, 'field6': classification_result}
        response = requests.post(url, params=params)
        
        if response.status_code == 200:
            print("Classification result sent successfully to ThingSpeak field6.")
        else:
            print("Failed to send classification result to ThingSpeak field3. Status code:", response.status_code)
            print("Response content:", response.content)
    except Exception as e:
        print("An error occurred during data submission:", str(e))
# Main function
def main():
    channel_id = '2909182'
    read_api_key = 'ZJ7PF5AEGTMCGIHD'
    write_api_key = '76EXYQMDD21K2SMD'
    model_file = 'lstm_metadata.joblib'

    # Load the classifier model
    classifier_model = load_model(model_file)
    if classifier_model is None:
        print("Failed to load classifier model. Exiting.")
        return

    while True:  # Run continuously
        # Get data from ThingSpeak
        data = get_thingspeak_data(channel_id, read_api_key)

        if data is not None:
            # Extract Conductivityerature and air quality from the data dictionary if needed
            entry = data['feeds'][0]
            N = entry.get('field1')
            P = entry.get('field2')
            K = entry.get('field3')
            Conductivity = entry.get('field4')
            PH = entry.get('field5')
            # Convert to float if not None
            N = float(N) if N is not None else None
            P = float(P) if P is not None else None
            K = float(K) if K is not None else None
            Conductivity = float(Conductivity) if Conductivity is not None else None
            PH = float(PH) if PH is not None else None
            print("Retrieved N:", N)
            print("Retrieved P:", P)
            print("Retrieved K:", K)
            print("Retrieved Conductivity:", Conductivity)
            print("Retrieved PH:", PH)
            # Classify the data if both Conductivityerature and air quality are valid
            classification_result = classify_data(classifier_model, N,P,K,Conductivity,PH)
            print("Classification result:", classification_result)

            # Send classification result to ThingSpeak if classification result is not None
            if classification_result is not None:
                send_classification_result(channel_id, write_api_key, classification_result)
        else:
            print("Failed to retrieve valid data from ThingSpeak.")

        # Wait for 9 seconds before fetching data again
        time.sleep(9)

if __name__ == "__main__":
    main()
