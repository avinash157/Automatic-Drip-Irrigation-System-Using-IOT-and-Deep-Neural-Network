from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from datetime import datetime, timedelta
import psycopg2
import requests

# ThingSpeak API URL (fetch all available records)
THINGSPEAK_URL = "https://api.thingspeak.com/channels/2909182/feeds.json"

# Function to fetch and insert only unique records
def fetch_and_insert_data():
    conn = psycopg2.connect(
        dbname="postgres",
        user="postgres",
        password="test@123",
        host="192.168.91.5",  # Updated PostgreSQL IP
        port="5432"
    )
    cursor = conn.cursor()

    # Fetch all data from ThingSpeak
    response = requests.get(THINGSPEAK_URL)
    if response.status_code == 200:
        data = response.json()
        feeds = data["feeds"]

        for entry in feeds:
            entry_id = entry["entry_id"]
            conductivity = int(entry["field1"])
            ph = float(entry["field2"])
            n = int(entry["field3"])
            p = int(entry["field4"])
            k = int(entry["field5"])
            result = int(entry["field6"])
            inserted_time = entry["created_at"]

            # Check if entry_id already exists
            cursor.execute("SELECT 1 FROM npk_data WHERE entry_id = %s;", (entry_id,))
            exists = cursor.fetchone()

            if not exists:  # Insert only if entry_id is new
                cursor.execute("""
                    INSERT INTO npk_data (entry_id, conductivity, ph, n, p, k, result, inserted_time)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                """, (entry_id, conductivity, ph, n, p, k, result, inserted_time))
                conn.commit()

    cursor.close()
    conn.close()

# Default DAG arguments
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2025, 4, 29),
    'retries': 1,
    'retry_delay': timedelta(minutes=1),
}

# Define DAG
dag = DAG(
    'npk_data_ingestion',
    default_args=default_args,
    description='DAG to fetch ThingSpeak data and insert unique records into PostgreSQL',
    schedule_interval='* * * * *',  # Runs every minute
)

# Define task
t1 = PythonOperator(
    task_id='fetch_and_insert_npk_data',
    python_callable=fetch_and_insert_data,
    dag=dag,
)