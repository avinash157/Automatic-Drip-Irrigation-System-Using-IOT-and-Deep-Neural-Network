import psycopg2
import psycopg2.extras
from flask import Flask, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Database connection parameters
DB_HOST = "192.168.91.5"
DB_NAME = "postgres"
DB_USER = "postgres"
DB_PASSWORD = "test@123"

def get_db_connection():
    """Create and return a database connection"""
    conn = psycopg2.connect(
        host=DB_HOST,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD
    )
    conn.autocommit = True
    return conn

@app.route('/api/columns', methods=['GET'])
def get_columns():
    """Get column names from the public.npk table"""
    conn = get_db_connection()
    cur = conn.cursor()
    
    # Query to get column information from the table
    cur.execute("""
        SELECT column_name, data_type 
        FROM information_schema.columns 
        WHERE table_schema = 'public' AND table_name = 'npk_data'
        ORDER BY ordinal_position
    """)
    
    columns = [{'name': row[0], 'type': row[1]} for row in cur.fetchall()]
    cur.close()
    conn.close()
    
    return jsonify(columns)

@app.route('/api/data', methods=['GET'])
def get_data():
    """Get all data from the public.npk table"""
    conn = get_db_connection()
    
    # Use DictCursor to get results as dictionaries
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    
    # Query all data from the table
    cur.execute('SELECT * FROM public.npk_data LIMIT 1000')  # Limit to 1000 rows for performance
    data = [dict(row) for row in cur.fetchall()]
    
    cur.close()
    conn.close()
    
    return jsonify(data)

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Get basic statistics about the public.npk table"""
    conn = get_db_connection()
    cur = conn.cursor()
    
    # Get total row count
    cur.execute('SELECT COUNT(*) FROM public.npk_data')
    row_count = cur.fetchone()[0]
    
    # Get recent entries (last 5)
    cur.execute('SELECT * FROM public.npk_data ORDER BY inserted_time DESC LIMIT 5')
    column_names = [desc[0] for desc in cur.description]
    recent_entries = []
    
    for row in cur.fetchall():
        entry = {}
        for i, value in enumerate(row):
            entry[column_names[i]] = value
        recent_entries.append(entry)
    
    cur.close()
    conn.close()
    
    return jsonify({
        'row_count': row_count,
        'recent_entries': recent_entries,
        'column_names': column_names
    })

@app.route('/')
def index():
    return app.send_static_file('index.html')

if __name__ == '__main__':
    # Run the Flask app
    app.run(debug=True)

print("Flask API is running on http://localhost:5000")