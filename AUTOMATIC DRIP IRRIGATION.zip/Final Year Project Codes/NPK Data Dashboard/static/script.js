// API base URL - change this to match your Flask server
const API_BASE_URL = 'http://localhost:5000/api';

// Function to fetch data from the API
async function fetchData(endpoint) {
    try {
        const response = await fetch(`${API_BASE_URL}/${endpoint}`);
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error(`Error fetching ${endpoint}:`, error);
        return null;
    }
}

// Function to create table headers from column names
function createTableHeaders(tableId, columns) {
    const headerRow = document.createElement('tr');
    
    columns.forEach(column => {
        const th = document.createElement('th');
        th.textContent = column;
        headerRow.appendChild(th);
    });
    
    const headerElement = document.getElementById(tableId);
    headerElement.innerHTML = '';
    headerElement.appendChild(headerRow);
}

// Function to populate table with data
function populateTable(tableId, data, columns) {
    const tableBody = document.getElementById(tableId);
    tableBody.innerHTML = '';
    
    if (!data || data.length === 0) {
        const row = document.createElement('tr');
        const cell = document.createElement('td');
        cell.colSpan = columns.length;
        cell.textContent = 'No data available';
        row.appendChild(cell);
        tableBody.appendChild(row);
        return;
    }
    
    data.forEach(item => {
        const row = document.createElement('tr');
        
        columns.forEach(column => {
            const cell = document.createElement('td');
            // Handle null values and format the data
            if (item[column] === null) {
                cell.textContent = 'N/A';
            } else if (typeof item[column] === 'object' && item[column] instanceof Date) {
                cell.textContent = item[column].toLocaleString();
            } else {
                cell.textContent = item[column];
            }
            row.appendChild(cell);
        });
        
        tableBody.appendChild(row);
    });
}

// Function to update the dashboard with stats and recent entries
async function updateStats() {
    const stats = await fetchData('stats');
    
    if (stats) {
        // Update total row count
        document.getElementById('row-count').textContent = stats.row_count;
        
        // Create headers for recent entries table
        createTableHeaders('recent-entries-header', stats.column_names);
        
        // Populate recent entries table
        populateTable('recent-entries-body', stats.recent_entries, stats.column_names);
    } else {
        document.getElementById('row-count').textContent = 'Error';
        document.getElementById('recent-entries-body').innerHTML = 
            '<tr><td>Error loading data</td></tr>';
    }
}

// Function to update all data table
async function updateAllData() {
    const columns = await fetchData('columns');
    const data = await fetchData('data');
    
    if (columns && data) {
        const columnNames = columns.map(col => col.name);
        
        // Create headers for all data table
        createTableHeaders('all-data-header', columnNames);
        
        // Populate all data table
        populateTable('all-data-body', data, columnNames);
    } else {
        document.getElementById('all-data-body').innerHTML = 
            '<tr><td>Error loading data</td></tr>';
    }
}

// Initialize the dashboard
function initDashboard() {
    updateStats();
    updateAllData();
    
    // Refresh data every 60 seconds
    setInterval(() => {
        updateStats();
        updateAllData();
    }, 1000);
}

// Load dashboard when the page is ready
document.addEventListener('DOMContentLoaded', initDashboard);